import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-sizes',
  templateUrl: './modal-sizes.component.html'
})
export class ModalSizesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
