import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gradient-card-container',
  templateUrl: './gradient-card-container.component.html'
})
export class GradientCardContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
