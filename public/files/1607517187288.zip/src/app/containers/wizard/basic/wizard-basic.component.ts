import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-basic',
  templateUrl: './wizard-basic.component.html'
})
export class WizardBasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
