import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecommerce',
  templateUrl: './ecommerce.component.html'
})
export class EcommerceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
