import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-default',
  templateUrl: './default.component.html'
})
export class DefaultComponent implements OnInit {

  constructor(
    private authService : AuthService
  ) { }

  async ngOnInit() {
    console.log('is authenicated')
    const user  =  await this.authService.getUser();
    console.log(user) 
  }

}
