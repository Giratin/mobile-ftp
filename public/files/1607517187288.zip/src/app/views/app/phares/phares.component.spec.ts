import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PharesComponent } from './phares.component';

describe('PharesComponent', () => {
  let component: PharesComponent;
  let fixture: ComponentFixture<PharesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PharesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PharesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
