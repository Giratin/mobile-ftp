import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BlankPageComponent } from './blank-page/blank-page.component';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { LayoutContainersModule } from 'src/app/containers/layout/layout.containers.module';
import { AjoutCategorie } from './ajout-categorie/ajout-categorie';
import { SortablejsModule } from 'ngx-sortablejs';
import { FormsModule } from '@angular/forms';
import { PagesContainersModule } from 'src/app/containers/pages/pages.containers.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PharesComponent } from './phares/phares.component';
import { BoutiqueComponent } from './boutique/boutique.component';
import { BootstrapModule } from 'src/app/components/bootstrap/bootstrap.module';

@NgModule({
  declarations: [BlankPageComponent, AppComponent, AjoutCategorie, PharesComponent, BoutiqueComponent],
  imports: [
    CommonModule,
    AppRoutingModule,
    SharedModule,
    LayoutContainersModule,
    SortablejsModule,
    FormsModule,
    ModalModule.forRoot(),
    BootstrapModule,
    PagesContainersModule,
  ],
})
export class AppModule {}
