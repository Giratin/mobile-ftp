import { Component, OnInit, OnDestroy, Renderer2 } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html'
})
export class UserComponent implements OnInit, OnDestroy {

  isMultiColorActive = environment.isMultiColorActive; 
  constructor(
    private renderer: Renderer2,
    private titleService : Title
    ) { }

  ngOnInit() {
    this.titleService.setTitle("Authenticate")
    this.renderer.addClass(document.body, 'background');
    this.renderer.addClass(document.body, 'no-footer');
  }

  ngOnDestroy() {
    this.renderer.removeClass(document.body, 'background');
    this.renderer.removeClass(document.body, 'no-footer');
  }
}
