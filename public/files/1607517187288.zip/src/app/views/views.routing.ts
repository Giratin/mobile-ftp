import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { AngularFireAuthGuard, redirectUnauthorizedTo, redirectLoggedInTo } from '@angular/fire/auth-guard';
import { environment } from 'src/environments/environment';
import { HomeComponent } from './home/home.component';

const redirectUnauthorizedToLogin = () =>  redirectUnauthorizedTo(['/user']) ;
const redirectLoggedInToItems = () => redirectLoggedInTo(['/']);
const adminRoot = environment.adminRoot.substr(1); // path cannot start with a slash 

let routes: Routes = [
  //canActivate: [AuthGuard]
  { path: adminRoot, loadChildren: () => import('./app/app.module').then(m => m.AppModule), canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin } },
  { path: 'office', loadChildren: () => import('./user/user.module').then(m => m.UserModule), data: { authGuardPipe: redirectLoggedInToItems } },
  { path: 'error', component: ErrorComponent },
  { path : '', redirectTo : '/error', pathMatch: 'full' },
  //{ path : '**', redirectTo : '/error', pathMatch :  "full" },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ViewRoutingModule { }
