export interface ITopRatedItem {
    id: number;
    image: string;
    order: string;
    title: string;
    rate: number;
    rateCount: string;
}

const data: ITopRatedItem[] = [
    {
        id: 0,
        image: '/assets/img/carousels/1.jpg',
        order: '1',
        title: 'Cheesecake',
        rate: 5,
        rateCount: '48'
    },
    {
        id: 1,
        image: '/assets/img/carousels/2.jpg',
        order: '2',
        title: 'Chocolate Cake',
        rate: 4,
        rateCount: '24'
    },
    {
        id: 2,
        image: '/assets/img/carousels/3.jpg',
        order: '3',
        title: 'Cremeschnitte',
        rate: 4,
        rateCount: '18'
    }
];

export default data;
