import { environment } from 'src/environments/environment';
const adminRoot = environment.adminRoot;
export interface IMenuItem {
  id?: string;
  icon?: string;
  label: string;
  to: string;
  newWindow?: boolean;
  subs?: IMenuItem[];
}

const data: IMenuItem[] = [
  {
    icon: 'iconsminds-pantone',
    label: 'Mon menu',
    to: `${adminRoot}/ajout-categorie`,
  },
  {
    icon: 'simple-icon-energy',
    label: 'Mes phares',
    to: `${adminRoot}/phares`,
  },
  {
    icon: 'iconsminds-shop-4',
    label: 'Ma boutique',
    to: `${adminRoot}/boutique`,
  },
  {
    icon: 'simple-icon-settings',
    label: 'Mon compte',
    to: `${adminRoot}/compte`,
  },
];
export default data;
