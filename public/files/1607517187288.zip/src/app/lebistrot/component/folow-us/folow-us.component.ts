import { Component, OnInit } from "@angular/core";
import { Inject } from "@angular/core";
import { MAT_BOTTOM_SHEET_DATA } from "@angular/material/bottom-sheet";
import {
  MatBottomSheet,
  MatBottomSheetRef,
} from "@angular/material/bottom-sheet";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
@Component({
  selector: "app-folow-us",
  templateUrl: "./folow-us.component.html",
  styleUrls: ["./folow-us.component.scss"],
})
export class FolowUsComponent implements OnInit {
  constructor(
    private _bottomSheetRef: MatBottomSheetRef<FolowUsComponent>,
    public dialogRef: MatDialogRef<FolowUsComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {}

  ngOnInit(): void {
    console.log(this.data);
  }
  close(): void {
    console.log(this);
    this._bottomSheetRef.dismiss();
  }
}
