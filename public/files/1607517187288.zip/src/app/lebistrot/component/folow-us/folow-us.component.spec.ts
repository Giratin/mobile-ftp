import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FolowUsComponent } from './folow-us.component';

describe('FolowUsComponent', () => {
  let component: FolowUsComponent;
  let fixture: ComponentFixture<FolowUsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FolowUsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FolowUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
