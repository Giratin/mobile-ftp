import { Component, OnInit } from "@angular/core";
import { Inject } from "@angular/core";
import { MAT_BOTTOM_SHEET_DATA } from "@angular/material/bottom-sheet";
import {
  MatBottomSheet,
  MatBottomSheetRef,
} from "@angular/material/bottom-sheet";

import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";

@Component({
  selector: "app-popin",
  templateUrl: "./popin.component.html",
  styleUrls: ["./popin.component.scss"],
})
export class PopinComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<PopinComponent>,
    private _bottomSheetRef: MatBottomSheetRef<PopinComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {}

  ngOnInit(): void {}

  close(): void {
    console.log(this);
    this._bottomSheetRef.dismiss();
  }
}
