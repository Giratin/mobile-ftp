import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";
import {
  MatBottomSheet,
  MatBottomSheetRef,
} from "@angular/material/bottom-sheet";
import { PopinComponent } from "../popin/popin.component";
import { MatDialog } from "@angular/material/dialog";

@Component({
  selector: "app-leb-carousel",
  templateUrl: "./carousel.component.html",
  styleUrls: ["./carousel.component.scss"],
})
export class LebCarouselComponent implements OnInit {
  @Output() onSubmit = new EventEmitter();


  SWIPE_ACTION = { LEFT: 'swipeleft', RIGHT: 'swiperight' };


  constructor(
    private router: Router,
    private _bottomSheet: MatBottomSheet,
    public dialog: MatDialog
  ) {}

  @Input("items") items: any[];
  public slidesNumber;
  public sliderWidth;
  public slideWidth;
  public movement = 15;
  time: number = 0;
  interval;
  page = 0;
  public boxSlideWidth;
  public temp;

  ngOnInit(): void {
    this.slidesNumber = this.items.length;
    this.boxSlideWidth = document.documentElement.clientWidth;
    this.sliderWidth = this.slidesNumber * document.documentElement.clientWidth;
    this.slideWidth = 0.8 * document.documentElement.clientWidth;
    this.temp = this.movement;
    // this.startTimer();
  }

  startTimer() {
    this.interval = setInterval(() => {
      this.movement += -(this.slideWidth + 20);
      this.page++;
      if (this.page == this.slidesNumber) {
        this.movement = 0;
        this.page = 0;
      }
    }, 4000);
  }
  panRight($event) {

    if (this.page == 0) {
      this.movement -= this.movement - 50;
    }
  }
  right($event) {
    if (this.page != 0) {
      if (this.page == this.slidesNumber - 1) {
        this.movement -= -(this.slideWidth + 20);
      } else {
        this.movement -= -(this.slideWidth + 20);
      }
      this.temp = this.movement;
      this.page--;
    }
  }

  left($event) {
    if (this.page != this.slidesNumber - 1) {
      if (this.page == this.slidesNumber - 2) {
        this.movement += -(this.slideWidth + 20);
      } else {
        this.movement += -(this.slideWidth + 20);
      }
      this.temp = this.movement;
      this.page++;
    }
  }
  panLeft($event) {
    if (this.page == this.slidesNumber - 1) {
      this.movement = this.temp - 50;
    }
  }
  stop($event) {
    this.movement = this.temp;
  }
  link(event) {
    if (this.items[event].type == "lien") {
      this.onSubmit.emit(this.items[event].lien);
    } else {
      this._bottomSheet.open(PopinComponent, {
        data: { data: this.items[event] },
        panelClass: "custom",
      });
    }
  }
}
