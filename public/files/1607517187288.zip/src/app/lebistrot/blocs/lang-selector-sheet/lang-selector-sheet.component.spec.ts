import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LangSelectorSheetComponent } from './lang-selector-sheet.component';

describe('LangSelectorSheetComponent', () => {
  let component: LangSelectorSheetComponent;
  let fixture: ComponentFixture<LangSelectorSheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LangSelectorSheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LangSelectorSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
