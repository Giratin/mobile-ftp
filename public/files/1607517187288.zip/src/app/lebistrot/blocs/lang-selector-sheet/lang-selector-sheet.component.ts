import { Component, OnInit } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { of } from "rxjs";
import {
  MatBottomSheet,
  MatBottomSheetRef,
} from "@angular/material/bottom-sheet";
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: "app-lang-selector-sheet",
  templateUrl: "./lang-selector-sheet.component.html",
  styleUrls: ["./lang-selector-sheet.component.scss"],
})
export class LangSelectorSheetComponent implements OnInit {
  constructor(
    private _bottomSheetRef: MatBottomSheetRef<LangSelectorSheetComponent>,
    private translate: TranslateService,
    private router : Router
  ) {}

  langList;
  currentLAng;
  ngOnInit(): void {
    this.currentLAng = localStorage.getItem("defaultLang");
    this.getListLang();
  }

  getListLang() {
    this.translate.get("LANG.LIST").subscribe((data) => {
      this.langList = Object.values(data);
    });
  }
  selectLang(data) {
    localStorage.setItem("defaultLang", data);
    var paths = location.pathname.split('/');
    paths.pop();
    var newPath = paths.join('/').concat(`/${data}`)
    this.close();
    this.router.navigateByUrl(newPath)
  }

  close(): void {
    this._bottomSheetRef.dismiss();
  }
}
