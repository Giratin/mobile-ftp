import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import {
  MatBottomSheet,
  MatBottomSheetRef,
} from "@angular/material/bottom-sheet";
import { FolowUsComponent } from "../../component/folow-us/folow-us.component";

@Component({
  selector: "app-leb-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.scss"],
})
export class LebHeaderComponent implements OnInit {
  @Input() popup;
  @Input() social;
  @Output() onSubmit = new EventEmitter();
  public title;
  constructor(private _bottomSheet: MatBottomSheet) {}

  public items = [];
  ngOnInit() {
    this.items = this.popup;
    this.title = localStorage.getItem("title");
    console.log(this.popup);
  }
  openBottomSheet(): void {
    this._bottomSheet.open(FolowUsComponent, {
      data: { data: this.social },
      panelClass: "social",
    });
  }
  trouver($event) {
    this.onSubmit.emit($event);
  }
}
