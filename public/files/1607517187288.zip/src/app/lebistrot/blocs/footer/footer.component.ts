import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  SimpleChanges,
  ViewChild,
  ElementRef,
} from "@angular/core";

@Component({
  selector: "app-leb-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.scss"],
})
export class LebFooterComponent implements OnInit {
  public menuWidth;
  public interval;
  @Input() menus;
  @Input() currentMenu;
  @Output() onSubmitRecherche = new EventEmitter();
  @Output() onSubmitMenu = new EventEmitter();
  @ViewChild("menuScroll", { read: ElementRef }) public menuScroll: ElementRef<
    any
  >;

  constructor() {}

  ngOnInit() {
    let widt = document.documentElement.clientWidth / 4.5;
    //this.menuWidth = widt - 28;
    this.menuWidth = Math.round(widt);
  }
  submitRecherche($event, i) {
    this.onSubmitRecherche.emit($event);
    this.onSubmitMenu.emit(i);
    this.currentMenu = i;
    console.log(this.menuScroll);
    this.menuScroll.nativeElement.scrollLeft = this.menuWidth * i;
    // this.menuScroll.nativeElement.scrollTo({
    //   left: this.menuScroll.nativeElement.scrollLeft - 150,
    //   behavior: "smooth",
    // });
  }

  ngOnChanges(changes: SimpleChanges) {}
}
