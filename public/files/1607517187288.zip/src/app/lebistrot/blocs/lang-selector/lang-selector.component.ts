import { Component, OnInit } from "@angular/core";
import {
  MatBottomSheet,
  MatBottomSheetRef,
} from "@angular/material/bottom-sheet";
import { LangSelectorSheetComponent } from "../lang-selector-sheet/lang-selector-sheet.component";
@Component({
  selector: "app-lang-selector",
  templateUrl: "./lang-selector.component.html",
  styleUrls: ["./lang-selector.component.scss"],
})
export class LangSelectorComponent implements OnInit {
  currentLang;

  constructor(private _bottomSheet: MatBottomSheet) {}

  openBottomSheet(): void {
    this._bottomSheet.open(LangSelectorSheetComponent);
  }

  ngOnInit(): void {
    this.currentLang = localStorage.getItem("defaultLang");
  }
}
