import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LebistrotComponent } from './lebistrot.component';

describe('LebistrotComponent', () => {
  let component: LebistrotComponent;
  let fixture: ComponentFixture<LebistrotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LebistrotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LebistrotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
