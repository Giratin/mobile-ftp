import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GlobalContainerComponent } from "./components/global-container/global-container.component";
import { PlatsComponent } from "./components/plats/plats.component";
import { VinsComponent } from "./components/vins/vins.component";
import { LebistrotComponent } from './lebistrot.component';
import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [
  {
    path: ':uid/:lang', component: LebistrotComponent/*, children: [
      { path: "", component: GlobalContainerComponent },
      { path: "plats", component: PlatsComponent },
      { path: "vins", component: VinsComponent },
    ],*/
  },
  { path: "not-found", component: NotFoundComponent },
];
// /user/login

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LebistrotRoutingModule { }
