import { Component,ChangeDetectionStrategy,ChangeDetectorRef,SimpleChanges,OnInit} from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Router, ActivatedRoute } from "@angular/router";
import { Title } from '@angular/platform-browser';
//import { TitleService } from "src/shared/services/title.service";

@Component({
  selector: 'app-lebistrot',
  templateUrl: './lebistrot.component.html',
  styleUrls: ['./lebistrot.component.scss']
})
export class LebistrotComponent implements OnInit {

  title;
  theme = "default";
  public currentMenu = [];
  public menu = [];
  public loadPage = false;
  public popup = [];
  public social = [];
  public activeMenu = 0;
  public interval;

  constructor(
    private translate: TranslateService,
    private http: HttpClient,
    private router: Router,
    private cd: ChangeDetectorRef,
    private route: ActivatedRoute,
    private titleService : Title
  ) { }

  langList = [ 'fr', 'en', 'de', 'es' , 'it' ]


  ngOnInit(): void {

    this.route.params.subscribe((params) => {
      if (params["uid"] && params["lang"]) {
        var trans;
        if(this.langList.indexOf(params["lang"]) === -1){
          localStorage.setItem("defaultLang", "fr");
          trans = "fr";
        }else{
          trans = params["lang"];
        }        
        
        this.translate.setDefaultLang(trans);

        this.getJSON().subscribe((data) => {
          if(data["id"] === params["uid"]){
            this.spinn();
            this.title = data.commerceName;
            this.titleService.setTitle(this.title);
            localStorage.setItem("title", this.title);
            for (let i = 0; i < data.menu.categoryList.length; i++) {
              this.menu.push(data.menu.categoryList[i]);
            }
            this.currentMenu = this.menu[0];
            this.popup = data.popUpList;
            this.social = data.socialMediaList;
          }else{
            this.router.navigateByUrl('/not-found')
          }
        },
          (err) => {
            console.log("error json file", err)
          }
        );
      } else {
        this.router.navigateByUrl('/not-found')
      }
    })

  }

  public getJSON(): Observable<any> {
    return this.http.get("../assets/commerce.json");
  }
  trouver($event) {
    this.currentMenu = $event;

    this.spinn();
  }
  updateMenu($event) {
    this.activeMenu = $event;
  }
  trouverMenu(event) {
    this.currentMenu = this.menu[event];
    this.activeMenu = event;

    this.spinn();
  }
  spinn() {
    this.loadPage = false;
    this.interval = setInterval(() => {
      this.loadPage = true;
    }, 1000);
  }

}
