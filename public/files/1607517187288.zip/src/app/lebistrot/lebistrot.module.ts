import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LebistrotRoutingModule } from './lebistrot-routing.module';
import { LebistrotComponent } from './lebistrot.component';
import { LebHeaderComponent } from "./blocs/header/header.component";
import { LebFooterComponent } from "./blocs/footer/footer.component";
import { LebCarouselComponent } from './component/carousel/carousel.component';
import { FolowUsComponent } from './component/folow-us/folow-us.component';

import { HttpClientModule, HttpClient } from "@angular/common/http";
import { LangSelectorComponent } from "./blocs/lang-selector/lang-selector.component";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { LangSelectorSheetComponent } from "./blocs/lang-selector-sheet/lang-selector-sheet.component";
import { MatBottomSheetModule } from "@angular/material/bottom-sheet";
import { MatToolbarModule } from "@angular/material/toolbar";
import { GlobalContainerComponent } from "./components/global-container/global-container.component";
import { MatCardModule } from "@angular/material/card";
import { MatDialogModule } from "@angular/material/dialog";
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from "@angular/material/form-field";
import { MatGridListModule } from "@angular/material/grid-list";
import { PlatsComponent } from './components/plats/plats.component';
import { VinsComponent } from './components/vins/vins.component';

//hammer
import { HammerModule, HammerGestureConfig, HAMMER_GESTURE_CONFIG } from "@angular/platform-browser";
import { SpinnerComponent } from "./components/spinner/spinner.component";
import { PopinComponent } from "./component/popin/popin.component";
import { MatDialogRef } from "@angular/material/dialog";
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { NotFoundComponent } from './not-found/not-found.component';

import * as hammer from "hammerjs";

export class MyHammerConfig extends HammerGestureConfig {
  overrides = <any>{
    swipe: { direction: hammer.DIRECTION_HORIZONTAL },
    pinch: { enable: false },
    rotate: { enable: false }
  };
}


@NgModule({
  declarations: [
    LebistrotComponent,
    LebHeaderComponent,
    LebFooterComponent,
    LangSelectorComponent,
    LangSelectorSheetComponent,
    GlobalContainerComponent,
    LebCarouselComponent,
    PlatsComponent,
    VinsComponent,
    SpinnerComponent,
    PopinComponent,
    FolowUsComponent,
    NotFoundComponent,],
  imports: [
    CommonModule,
    LebistrotRoutingModule,
    HttpClientModule,
    MatToolbarModule,
    MatCardModule,
    MatDialogModule,
    HammerModule,
    MatGridListModule,
    MatProgressSpinnerModule,
    MatBottomSheetModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: "fill" },
    },
    {
      provide: MatDialogRef,
      useValue: {
        close: (dialogResult: any) => { },
      },
    },
    {
      provide: HAMMER_GESTURE_CONFIG,
      useClass: MyHammerConfig
    }
  ],
  entryComponents: [LangSelectorSheetComponent],
  bootstrap: [LebistrotComponent]
})
export class LebistrotModule { }


// required for AOT compilation
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

