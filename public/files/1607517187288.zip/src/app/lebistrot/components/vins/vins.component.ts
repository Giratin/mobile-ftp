import { Component, OnInit, HostListener } from "@angular/core";
import { ViewChild, ElementRef, AfterViewInit } from "@angular/core";
const WINDOW = window;

@Component({
  selector: "app-vins",
  templateUrl: "./vins.component.html",
  styleUrls: ["./vins.component.scss"],
})
export class VinsComponent implements OnInit {
  public vins;
  public sticky = false;
  public sizesVins = [];
  public types = [];
  public loadMore;
  public colisions;
  public headType;
  @ViewChild("loadNext") btnLoadMore: ElementRef;
  constructor() {}

  // The checker
  public elementIsInViewport(el: HTMLElement) {
    const scroll = WINDOW.scrollY || WINDOW.pageYOffset;
    const boundsTop = el.getBoundingClientRect().top + scroll;

    return boundsTop <= scroll;
  }
  ngOnInit(): void {
    this.vins = [
      {
        type: "Rouges",
        sizes: [
          { size: "Verre 16cl" },
          { size: "Caraffe 25cl" },
          { size: "Caraffe 50cl" },
          { size: "Btl 75cl" },
        ],
        vins: [
          {
            name: "Bordeaux",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Morgon",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Pessac Leognan",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Merlot",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Muscadet sur lie",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Chardonnay",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Cotes de provinces",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "La demoiselle sans géne",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Chardonnay",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
        ],
      },
      {
        type: "Blanc",
        sizes: [
          { size: "Verre 16cl" },
          { size: "Caraffe 25cl" },
          { size: "Caraffe 50cl" },
          { size: "Btl 75cl" },
        ],
        vins: [
          {
            name: "Bordeaux",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Morgon",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Pessac Leognan",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Merlot",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Muscadet sur lie",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Chardonnay",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Cotes de provinces",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "La demoiselle sans géne",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
          {
            name: "Chardonnay",
            description: "description",
            prix: [
              { prix: "4.90 €" },
              { prix: "9 €" },
              { prix: "16 €" },
              { prix: "24 €" },
            ],
          },
        ],
      },
    ];
    console.log(this.vins);
    this.sizesVins = this.vins[0].sizes;
    console.log(this.sizesVins);
    for (let i = 0; i < this.vins.length; i++) {
      this.types.push(this.vins[i].type);
    }
    console.log(this.types);
    this.headType = this.types[0];
  }

  @HostListener("window:scroll", ["$event"])
  onScroll($event) {
    for (let i = 0; i < this.types.length; i++) {
      let element = document.getElementById("div" + i);
      this.loadMore = this.elementIsInViewport(element);
      if (this.loadMore) {
        this.headType = this.types[i];
      }
    }
    if (this.loadMore) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
    if (window.pageYOffset > 230) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
  }
}
