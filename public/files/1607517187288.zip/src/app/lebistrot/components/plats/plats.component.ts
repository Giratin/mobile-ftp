import { Component, OnInit, HostListener } from "@angular/core";

@Component({
  selector: "app-plats",
  templateUrl: "./plats.component.html",
  styleUrls: ["./plats.component.scss"],
})
export class PlatsComponent implements OnInit {
  public plats;
  public sticky = false;
  constructor() {}

  ngOnInit(): void {
    this.plats = [
      {
        titre: "plat 1",
        description: "description 1",
        prix: "18 €",
      },
      {
        titre: "plat 2",
        description: "description 2",
        prix: "18 €",
      },
      {
        titre: "plat 3",
        description: "description 3",
        prix: "18 €",
      },
      {
        titre: "plat 4",
        description: "description 4",
        prix: "18 €",
      },
      {
        titre: "plat 5",
        description: "description 5",
        prix: "18 €",
      },
      {
        titre: "plat 6",
        description: "description 6",
        prix: "18 €",
      },
      {
        titre: "plat 7",
        description: "description 7",
        prix: "18 €",
      },
      {
        titre: "plat 8",
        description: "description 7",
        prix: "18 €",
      },
      {
        titre: "plat 9",
        description: "description 7",
        prix: "18 €",
      },
      {
        titre: "plat 10",
        description: "description 7",
        prix: "18 €",
      },
      {
        titre: "plat 11",
        description: "description 7",
        prix: "18 €",
      },
      {
        titre: "plat 12",
        description: "description 7",
        prix: "18 €",
      },
      {
        titre: "plat 13",
        description: "description 7",
        prix: "18 €",
      },
    ];
  }

  @HostListener("window:scroll")
  onWindowScroll() {
    if (window.pageYOffset > 216) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
    console.log(this.sticky);
  }
}
