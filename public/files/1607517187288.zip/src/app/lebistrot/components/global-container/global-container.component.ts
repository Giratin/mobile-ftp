import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  SimpleChanges,
  HostListener,
  AfterViewInit,
} from "@angular/core";
import { ActivatedRoute, Router } from '@angular/router';
const WINDOW = window;

@Component({
  selector: "app-global-container",
  templateUrl: "./global-container.component.html",
  styleUrls: ["./global-container.component.scss"],
})
export class GlobalContainerComponent implements OnInit, AfterViewInit {
  @Input() currentMenu;
  public sticky = false;
  public content;
  public categoryName;
  public subCategoryLists;
  public subCategoryName;
  public subCategory;
  public sizes;
  public types = [];
  public loadMore;
  public headType;
  public nbrListPrice;
  public tdWidth = 100;

  constructor(
    private route : ActivatedRoute,
    private router : Router
  ) {}


  ngOnInit(): void {
    this.headType = this.types[0];
  }

  ngAfterViewInit(): void {
    /*this.route.params.subscribe((params)=>{
      console.log('params ', params)
      if(params["uid"] && params["lang"]){ 
        console.log("test uid" ,params["uid"] )
      }else{
        this.router.navigateByUrl('/not-found')
      }
    })*/
  }

  // The checker
  public elementIsInViewport(el: HTMLElement) {
    const scroll = WINDOW.scrollY || WINDOW.pageYOffset;
    const boundsTop = el.getBoundingClientRect().top + scroll - 70;
    return boundsTop <= scroll;
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log("current menu is ", this.currentMenu)
    this.content = this.currentMenu;
    this.categoryName = this.content.categoryName;
    this.subCategoryLists = this.content.subCategoryList;
    if (this.subCategoryName == "NoName") {
      this.subCategoryName = "";
    }
    this.types = [];
    for (let i = 0; i < this.content.subCategoryList.length; i++) {
      if (this.content.subCategoryList[i].subCategoryName != "NoName") {
        this.types.push(this.content.subCategoryList[i].subCategoryName);
      }
    }
    if (this.content.subCategoryList[0].sizeItemList) {
      this.sizes = this.content.subCategoryList[0].sizeItemList;
      this.nbrListPrice = this.content.subCategoryList[0].sizeItemList.length;
    }
    console.log(this.sizes);
    if (this.nbrListPrice) {
      this.tdWidth = 100 / this.nbrListPrice;
    }
  }

  @HostListener("window:scroll", ["$event"])
  onScroll($event) {
    for (let i = 0; i < this.types.length; i++) {
      let element = document.getElementById("div" + i);
      this.loadMore = this.elementIsInViewport(element);
      if (this.loadMore) {
        this.headType = this.types[i];
      }
    }
    if (this.loadMore) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
    if (window.pageYOffset > 230) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
  }
}
