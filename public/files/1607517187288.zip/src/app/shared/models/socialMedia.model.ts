export interface SocialMedia {
    name: string;
    url: string;
}
