export interface ICredentails {
    email : string;
    password: string;
}

export interface IUser {
    _id : string;
    firstName : string;
    lastName: string;
    email: string;
    password: string;
    createdAt: Date;
    updatedAt: Date;
}

export interface IPayload{
    iss: string; //issuer
    iat : Date; //created At
    exp : Date; //expires in
    sub : {
      id : string;
      name : string; 
    }// user details
  }