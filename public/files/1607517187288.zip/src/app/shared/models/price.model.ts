export interface Price {
    price: string;
}