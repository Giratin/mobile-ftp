import { Category } from "./category.model";

export interface Menu {
    categoryList: Category[];
}