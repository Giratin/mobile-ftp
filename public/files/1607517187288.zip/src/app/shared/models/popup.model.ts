export interface PopUp {
    image: string;
    description: string;
    description1: string;
    description2: string;
    prix: string;
    type: string;
    lien: string;
}