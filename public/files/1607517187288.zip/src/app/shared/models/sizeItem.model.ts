export interface SizeItem {
    size: string;
}
