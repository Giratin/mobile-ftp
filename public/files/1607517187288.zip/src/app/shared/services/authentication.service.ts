import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import jwt_decode from 'jwt-decode';
import { IPayload, ICredentails } from '../models/user.model';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private readonly baseUrl = environment.apiUrl;

  constructor(
    private http : HttpClient,
    private router : Router
  ) { }

  public logIn(credentials : ICredentails){
    // auth/signin
    return this.http.post(`${this.baseUrl}/`, credentials);
  }
  
  public signOut(){
    localStorage.removeItem('__SEC-ID');
    this.router.navigateByUrl('/user/login');
  }
  
  public saveToken(token :string){
    localStorage.setItem('__SEC-ID',token);
  }

  get Token(){
    return localStorage.getItem('__SEC-ID');
  }

  get isAuthenticated() : boolean{
    return this.Payload ? true : false;
  }

  get Payload() : IPayload {
    const token = this.Token;
    if(token){
      return jwt_decode(token);
    }
    return null;
  }
}
