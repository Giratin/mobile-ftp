import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'office', loadChildren: () => import('./views/views.module').then(m => m.ViewsModule) },
  { path: '', loadChildren: () => import('./lebistrot/lebistrot.module').then(m => m.LebistrotModule) },
  { path : '**' , redirectTo : '/not-found' }
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
